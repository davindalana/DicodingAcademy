// Fungsi menjumlahkan dua angka
function tambah(a, b) {
    return a + b;
};

// Fungsi mengurangi dua angka
function kurang(a, b) {
    return a - b;
};

// Fungsi mengalikan dua angka
function kali(a, b) {
    return a * b;
};

// Fungsi membagi dua angka
function bagi(a, b) {
    return a / b;
};

// Mengeksport semua fungsi
export { tambah, kurang, kali, bagi };