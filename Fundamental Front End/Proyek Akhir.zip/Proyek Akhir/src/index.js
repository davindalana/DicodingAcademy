import "regenerator-runtime";
import "bootstrap/dist/css/bootstrap.min.css";
import "./scripts/main.js";
import "./styles/main.css";
